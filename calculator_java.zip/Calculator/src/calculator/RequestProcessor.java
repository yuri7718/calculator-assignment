package calculator;
import java.io.*;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.json.JSONObject;

class RequestProcessor implements Runnable {
	private Socket socket = null;
	private OutputStream os = null;
	private BufferedReader in = null;
	private DataInputStream dis = null;
	private String msgToClient = "HTTP/1.1 200 OK\n"
	+ "Server: HTTP server/0.1\n"
	+ "Access-Control-Allow-Origin: *\n\n";
	private JSONObject jsonObject = new JSONObject();
	
	public RequestProcessor(Socket Socket) {
		super();
		try {
			socket = Socket;
			in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			os = socket.getOutputStream();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void run() {
		//write your code here
		
		Map<String, String> params = new HashMap<>();
		try {
			// sample: http://localhost:8080/leftOperand=5&rightOperand=10&operation=+
			for (String query: in.readLine().split("&")) {
				String[] keyValPair = query.split("=");
				String key = keyValPair[0];
				String val = keyValPair[1];

				if (key.contains("leftOperand")) {
					params.put("leftOperand", val);
				} else if (key.contains("rightOperand")) {
					params.put("rightOperand", val);
				} else if (key.contains("operation")) {
					params.put("operation", val.substring(0, val.indexOf(" ")));
				}
			}
		} catch (Exception e) { }
		
		if (!validateQuery(params)) return;
		
		calculate(params);
		
		//end of your code
		String response = msgToClient + jsonObject.toString();

		try {
			os.write(response.getBytes());
			os.flush();
			socket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	// return true if the query format is correct, otherwise return false
	private boolean validateQuery(Map<String, String> params) {
		if (params.size() != 3) return false;
		for (Entry<String, String> entry: params.entrySet()) {
			if (entry.getKey().equals("leftOperand") || entry.getKey().equals("rightOperand")) {
				try {
					Double.parseDouble(entry.getValue());
				} catch (NumberFormatException e) {
					return false;
				}
			} else {
				String op = entry.getValue();
				if (!(op.equals("addition") || op.equals("subtraction") || op.equals("multiplication") || op.equals("division") || op.equals("remainder"))) {
					return false;
				}
			}
		}
		return true;
	}
	
	private void calculate(Map<String, String> params) {
		double result = 0;
		
		double leftOperand = Double.parseDouble(params.get("leftOperand"));
		double rightOperand = Double.parseDouble(params.get("rightOperand"));
		
		switch (params.get("operation")) {
			case "addition":
				result = leftOperand + rightOperand;
				jsonObject.put("Expression", params.get("leftOperand") + " + " + params.get("rightOperand"));
				break;
			case "subtraction":
				result = leftOperand - rightOperand;
				jsonObject.put("Expression", params.get("leftOperand") + " - " + params.get("rightOperand"));
				break;
			case "multiplication":
				result = leftOperand * rightOperand;
				jsonObject.put("Expression", params.get("leftOperand") + " * " + params.get("rightOperand"));
				break;
			case "division":
				result = leftOperand / rightOperand;
				jsonObject.put("Expression", params.get("leftOperand") + " / " + params.get("rightOperand"));
				break;
			case "remainder":
				result = leftOperand % rightOperand;
				jsonObject.put("Expression", params.get("leftOperand") + " % " + params.get("rightOperand"));
				break;
			default:
				break;
		}
		jsonObject.put("Result", result);
	}
}